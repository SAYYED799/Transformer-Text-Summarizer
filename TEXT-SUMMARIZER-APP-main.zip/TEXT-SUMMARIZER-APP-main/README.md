# 🚀 Transformer Text Summarizer

> A Generative AI powered Text Summarization Web Application built using **Google T5 Transformer**, **FastAPI**, and **HTML/CSS/JavaScript**.

![Python](https://img.shields.io/badge/Python-3.12-blue?style=for-the-badge&logo=python)
![FastAPI](https://img.shields.io/badge/FastAPI-Backend-green?style=for-the-badge&logo=fastapi)
![Transformers](https://img.shields.io/badge/HuggingFace-Transformers-yellow?style=for-the-badge)
![PyTorch](https://img.shields.io/badge/PyTorch-DeepLearning-red?style=for-the-badge&logo=pytorch)
![License](https://img.shields.io/badge/License-MIT-purple?style=for-the-badge)

---

# 📖 Overview

This project is an **AI-powered Text Summarization application** that generates concise summaries from long dialogues using the **Google T5 Transformer Model**.

The model was fine-tuned on the **SAMSum Dialogue Summarization Dataset** in **Google Colab** and later deployed locally using **FastAPI** with a custom frontend built using **HTML, CSS, and JavaScript**.

---

# ✨ Features

- 🧠 Transformer-based Text Summarization
- 🤖 Fine-tuned Google T5 Model
- ⚡ FastAPI Backend
- 🎨 Interactive Web Interface
- 📄 Summarizes Long Dialogues
- 🚀 Fast Inference
- 🔥 REST API Support
- 💻 Local Deployment

---

# 🛠 Tech Stack

| Category | Technology |
|----------|------------|
| Language | Python |
| Deep Learning | PyTorch |
| Transformer | Google T5 |
| NLP Library | Hugging Face Transformers |
| Backend | FastAPI |
| Frontend | HTML, CSS, JavaScript |
| Dataset | SAMSum Dialogue Dataset |
| Development | Google Colab + VS Code |

---

# 📂 Project Structure

```
TEXT-SUMMARIZER-APP
│
├── app.py
├── index.html
├── requirements.txt
├── README.md
├── .gitignore
└── saved_summary_model/
```

---

# ⚙️ How It Works

```
User Input
      │
      ▼
Frontend (HTML/CSS/JS)
      │
      ▼
FastAPI Backend
      │
      ▼
Text Cleaning
      │
      ▼
T5 Tokenizer
      │
      ▼
Fine-Tuned T5 Model
      │
      ▼
Generated Summary
      │
      ▼
Displayed on Web Page
```

---

# 🧠 Model Training Pipeline

```
SAMSum Dataset
      │
      ▼
Data Cleaning
      │
      ▼
Tokenization
      │
      ▼
Fine-tuning Google T5
      │
      ▼
Model Training
      │
      ▼
Save Trained Model
      │
      ▼
FastAPI Deployment
```

---

# 📊 Dataset

**Dataset:** SAMSum Dialogue Summarization Dataset

The dataset contains thousands of real-life conversations paired with human-written summaries, making it ideal for dialogue summarization tasks.

---

# 🚀 Installation

Clone the repository

```bash
git clone https://github.com/ritikasainii1234-cloud/TEXT-SUMMARIZER-APP.git
```

Move inside the project

```bash
cd TEXT-SUMMARIZER-APP
```

Install dependencies

```bash
pip install -r requirements.txt
```

Run the application

```bash
uvicorn app:app --reload
```

Open in browser

```
http://127.0.0.1:8000
```

---

# 📸 Screenshots

> Add screenshots here

### Home Page

```
images/home.png
```

### Generated Summary

```
images/output.png
```

---

# 📈 Future Improvements

- 🌐 Online Deployment
- 🎙 Speech to Summary
- 🌍 Multi-language Summarization
- 📄 PDF & DOCX Summarization
- 🤖 Larger Transformer Models (FLAN-T5, BART)

---

# ⚠️ Note

The trained model is **not included** in this repository because the model file exceeds GitHub's file size limit.

To run the project locally, place the trained model inside:

```
saved_summary_model/
```

---

# 👨‍💻 Author

**Ritika Saini**

AI & Machine Learning Engineer

GitHub:
https://github.com/ritikasainii1234-cloud

---

## ⭐ If you like this project, don't forget to Star the repository!
